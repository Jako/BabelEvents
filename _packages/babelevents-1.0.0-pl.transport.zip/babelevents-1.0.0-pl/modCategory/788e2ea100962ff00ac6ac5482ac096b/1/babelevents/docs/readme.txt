BabelEvents
===========

Generic BabelEvent Plugins

Look into the example plugin code in https://github.com/Jako/babelevents/blob/master/core/components/babelevents/elements/plugins/babelevents.plugin.php and change it to your needs.
